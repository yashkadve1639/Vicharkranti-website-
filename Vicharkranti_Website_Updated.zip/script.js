/* =========================================
   VICHARKRANTI YUVA VAKTA 2027
   Common JavaScript for all website pages
========================================= */

(() => {
    'use strict';

    const onReady = (callback) => {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', callback, { once: true });
        } else {
            callback();
        }
    };

    onReady(() => {
        const loader = document.getElementById('loader');
        const header = document.getElementById('header');
        const menuBtn = document.getElementById('menuBtn');
        const closeBtn = document.getElementById('closeBtn');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        const backToTop = document.getElementById('backToTop');

        // Hide the page loader after the page is ready.
        const hideLoader = () => {
            if (loader) loader.classList.add('loader-hide');
        };
        window.addEventListener('load', hideLoader, { once: true });
        window.setTimeout(hideLoader, 1200); // Fallback for slow or cached loads.

        // Mobile navigation drawer.
        const openMenu = () => {
            if (!sidebar || !overlay) return;
            sidebar.classList.add('active');
            overlay.classList.add('active');
            document.body.classList.add('menu-open');
            if (menuBtn) menuBtn.setAttribute('aria-expanded', 'true');
        };

        const closeMenu = () => {
            if (sidebar) sidebar.classList.remove('active');
            if (overlay) overlay.classList.remove('active');
            document.body.classList.remove('menu-open');
            if (menuBtn) menuBtn.setAttribute('aria-expanded', 'false');
        };

        if (menuBtn) menuBtn.addEventListener('click', openMenu);
        if (closeBtn) closeBtn.addEventListener('click', closeMenu);
        if (overlay) overlay.addEventListener('click', closeMenu);

        if (sidebar) {
            sidebar.querySelectorAll('a').forEach((link) => {
                link.addEventListener('click', closeMenu);
            });
        }

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') closeMenu();
        });

        // Header appearance and back-to-top button while scrolling.
        const handleScroll = () => {
            const scrollY = window.scrollY || document.documentElement.scrollTop;
            if (header) header.classList.toggle('scrolled', scrollY > 30);
            if (backToTop) backToTop.classList.toggle('show', scrollY > 350);
        };
        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll();

        if (backToTop) {
            backToTop.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        // Reveal cards and sections smoothly as they enter the viewport.
        const revealItems = document.querySelectorAll('.reveal');
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries, currentObserver) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('revealed');
                        currentObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });

            revealItems.forEach((item) => observer.observe(item));
        } else {
            revealItems.forEach((item) => item.classList.add('revealed'));
        }
    });
})();
